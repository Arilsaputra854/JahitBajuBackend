-- AlterTable
ALTER TABLE `otp` MODIFY `otp` TEXT NOT NULL;
