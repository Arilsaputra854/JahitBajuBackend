-- AlterTable
ALTER TABLE `users` ADD COLUMN `email_verified` BOOLEAN NULL DEFAULT false;
