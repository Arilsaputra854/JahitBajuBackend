-- AlterTable
ALTER TABLE `orders` ADD COLUMN `payment_url` VARCHAR(191) NOT NULL DEFAULT '';
